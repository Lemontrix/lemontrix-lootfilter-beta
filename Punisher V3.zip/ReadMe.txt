You've added and downloaded some custom sounds for you filter. Those sound files need to be placed in the same folder as your filter file.

This is a list of all used custom sounds:
- Zizaran_6veryvaluable.mp3
- Zizaran_1maybevaluable.mp3
- Zizaran_3uniques.mp3
- Zizaran_2currency.mp3
- Zizaran_4maps.mp3
- Zizaran_5highmaps.mp3
